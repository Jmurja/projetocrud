<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de login</title>
</head>
<body>
    <form class="" method="post" action="login/login.php">
        Usuário: <input type="text" id="usuario" name="usuario">
        Senha: <input type="password" id="senha" name="senha">
        <input type="submit" name="enviar" value="Enviar">
    </form>    
</body>
</html>